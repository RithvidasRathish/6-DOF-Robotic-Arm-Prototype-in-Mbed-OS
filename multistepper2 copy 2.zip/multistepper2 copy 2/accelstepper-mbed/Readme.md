AccelStepper Library from AirSpayce Pty Ltd, ported to MBED

see: http://www.airspayce.com/mikem/arduino/AccelStepper/index.html

Based on version: 1.59

Updated by 3wnbr1 from the work of https://github.com/jrv/AccelStepper
